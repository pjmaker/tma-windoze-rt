#include <pwd.h>
int xx(int a, int b) {
}

int main(int argc, char *argv[]) {
  printf("Size = %d, %d\n", sizeof(__uid_t), 1<<4);
}

int yy(int a, int b) {
}
