/*
 * cmpWrite.h --
 *
 *  Declarations of the interfaces exported by the Compiler package.
 *
 * Copyright (c) 1998 by Scriptics Corporation.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * RCS: @(#) $Id: cmpWrite.h,v 1.1.1.1 2009/05/09 16:29:01 pcmacdon Exp $
 */

#ifndef _CMPWRITE
#define _CMPWRITE

#include "tcl.h"

/*
 * The default error message displayed when we cannot find a Loader package:
 * variable name in the Compiler package, and default value.
 */

#define LOADER_ERROR_VARIABLE "LoaderError"
#define LOADER_ERROR_MESSAGE "The TclPro ByteCode Loader is not available or does not support the correct version"

/*
 *----------------------------------------------------------------
 * Procedures exported by cmpWrite.c and cmpWPkg.c
 *----------------------------------------------------------------
 */

#undef TCL_STORAGE_CLASS
#ifdef BUILD_tclcompiler
#   define TCL_STORAGE_CLASS DLLEXPORT
#else
#   define TCL_STORAGE_CLASS DLLIMPORT
#endif

EXTERN int	Compiler_CompileObjCmd _ANSI_ARGS_((ClientData dummy,
			Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]));
EXTERN int	Compiler_CompileFile _ANSI_ARGS_((Tcl_Interp *interp,
			char *inFilePtr, char *outFilePtr, char *preamblePtr));
EXTERN int	Compiler_CompileObj _ANSI_ARGS_((Tcl_Interp *interp,
			Tcl_Obj *objPtr));
EXTERN int	Compiler_GetBytecodeExtensionObjCmd
			_ANSI_ARGS_((ClientData dummy,
			Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]));

EXTERN CONST char *
		CompilerGetPackageName _ANSI_ARGS_((void));

EXTERN int	Compiler_Init _ANSI_ARGS_((Tcl_Interp *interp));


/*
 * Declarations for functions defined in this file.
 */

EXTERN int Tclcompiler_Init _ANSI_ARGS_((Tcl_Interp *interp));


#undef TCL_STORAGE_CLASS
#define TCL_STORAGE_CLASS DLLIMPORT

#endif /* _CMPWRITE */
