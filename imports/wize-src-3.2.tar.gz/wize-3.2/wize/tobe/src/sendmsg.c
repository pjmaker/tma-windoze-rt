#include <tcl.h>
#include <stdlib.h>
#include <shlobj.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

TCL_DECLARE_MUTEX(initLock)
int MsgTblinit=0;
Tcl_HashTable MsgTbl;

static Tcl_Obj *
GetSysMsgObj (DWORD id)
{
    int chars;
    char sysMsgSpace[512];

    chars = wsprintf(sysMsgSpace, "[%u] ", id);
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_IGNORE_INSERTS |
	    FORMAT_MESSAGE_MAX_WIDTH_MASK, 0L, id, 0, sysMsgSpace, (512-chars),
	    0);
    return Tcl_NewStringObj(sysMsgSpace, -1);
}

/*
  Return 1 or all windows with this pid.
*/
static int
PidHwndObjCmd (ClientData cData, Tcl_Interp *interp, int objc,
		   struct Tcl_Obj * CONST objv[])
{
    HWND h;
    int num;
    Tcl_Obj *o;
    if (objc != 2 && objc != 3) {
	Tcl_WrongNumArgs(interp, 1, objv, "<PID> ?ALL?");
	return TCL_ERROR;
    }
    if (objc == 3) {
	o = Tcl_NewListObj(0,0);
    }

    if (Tcl_GetIntFromObj(interp, objv[1], &num) != TCL_OK) {
	Tcl_AppendResult(interp, " <PID> didn't convert to a decimal.", NULL);
	return TCL_ERROR;
    }
    h = GetTopWindow(0 );
    while ( h )
    {
	DWORD pid;
	DWORD dwTheardId = GetWindowThreadProcessId( h,&pid);

	if ( pid == num )
	{
	    /* here h is the handle to the window */
	    if (objc==2) break;
	    Tcl_ListObjAppendList(interp, o, Tcl_NewIntObj((int)h));
	}
	h = GetNextWindow( h , GW_HWNDNEXT);
    }
    if (objc==2) o = Tcl_NewIntObj((int)h);
    Tcl_SetObjResult(interp, o);
    return TCL_OK;
}

/*
 *----------------------------------------------------------------------
 *
 * CmdSendMessage --
 *
 *  uses the window's sendmessage function.
 *
 * Results:
 *  what sendmessage returns
 *
 * Side effects:
 *  we hope not.
 *
 *----------------------------------------------------------------------
 */
static int
SendMessageObjCmd (ClientData cData, Tcl_Interp *interp, int objc,
		   struct Tcl_Obj * CONST objv[])
{
    HWND hWnd = 0L;
    UINT Msg = 0;
    WPARAM wParam = 0L;
    LPARAM lParam = 0L;
    int num;
    DWORD result;
    LRESULT rtn;
    Tcl_HashEntry *e;

    if (objc < 5 || objc > 5) {
	Tcl_WrongNumArgs(interp, 1, objv, "<hWnd> <msgnum|msgname> <wParam> <lParam>");
	return TCL_ERROR;
    }

    if (Tcl_GetIntFromObj(interp, objv[1], &num) != TCL_OK) {
	Tcl_AppendResult(interp, " <hWnd> didn't convert to a decimal.", NULL);
	return TCL_ERROR;
    }
    hWnd = (HWND) num;

    if (Tcl_GetIntFromObj(NULL, objv[2], &num) != TCL_OK) {
	/* it isn't a number, so it must be the name of
	 a message.  Look it up in the message hash table.
	*/
	if (!(e = Tcl_FindHashEntry(&MsgTbl, Tcl_GetString(objv[2])))) {
	    // no dice.
	    Tcl_AppendResult(interp, "Message name (", Tcl_GetString(objv[2]), ") was not found in the list", NULL);
	    return TCL_ERROR;
	}
	Msg = (UINT) Tcl_GetHashValue(e);
    } else {
	Msg = (UINT) num;
    }

    /* we'll need some more stuff here for converting wParam and lParam */
    if (Tcl_GetIntFromObj(interp, objv[3], &num) != TCL_OK) {
	Tcl_AppendResult(interp, " <wParam> didn't convert to a decimal.", 0L);
	return TCL_ERROR;
    }
    wParam = (WPARAM) num;

    if (Tcl_GetIntFromObj(interp, objv[4], &num) != TCL_OK) {
	Tcl_AppendResult(interp, " <lParam> didn't convert to a decimal.", 0L);
	return TCL_ERROR;
    }
    lParam = (LPARAM) num;

    rtn = SendMessageTimeout(hWnd, Msg, wParam, lParam, SMTO_ABORTIFHUNG,
	    4000, &result);

    if (rtn == 0) {
	DWORD err = GetLastError();
	if (err = NO_ERROR) {
	    Tcl_SetObjResult(interp, Tcl_NewStringObj(
		    "Operation timed-out.", -1));
	} else {
	    Tcl_SetObjResult(interp, GetSysMsgObj(err));
	}
	return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewLongObj(result));
    return TCL_OK;
};


void MsgTblAdd(char *str, int key) {
    int isNew = 0;
    Tcl_HashEntry *e = Tcl_CreateHashEntry(&MsgTbl, str, &isNew);
    if (isNew) {
	Tcl_SetHashValue(e, (ClientData)key);
    }
}

void Fill_MsgTable ()
{
    Tcl_InitHashTable(&MsgTbl, TCL_STRING_KEYS);
    MsgTblAdd("WM_NULL", WM_NULL);
    MsgTblAdd("WM_CREATE", WM_CREATE);
    MsgTblAdd("WM_DESTROY", WM_DESTROY);
    MsgTblAdd("WM_MOVE", WM_MOVE);
    MsgTblAdd("WM_SIZE", WM_SIZE);
    MsgTblAdd("WM_ACTIVATE", WM_ACTIVATE);
    MsgTblAdd("WM_SETFOCUS", WM_SETFOCUS);
    MsgTblAdd("WM_KILLFOCUS", WM_KILLFOCUS);
    MsgTblAdd("WM_ENABLE", WM_ENABLE);
    MsgTblAdd("WM_SETREDRAW", WM_SETREDRAW);
    MsgTblAdd("WM_SETTEXT", WM_SETTEXT);
    MsgTblAdd("WM_GETTEXT", WM_GETTEXT);
    MsgTblAdd("WM_GETTEXTLENGTH", WM_GETTEXTLENGTH);
    MsgTblAdd("WM_PAINT", WM_PAINT);
    MsgTblAdd("WM_CLOSE", WM_CLOSE);
    MsgTblAdd("WM_QUERYENDSESSION", WM_QUERYENDSESSION);
    MsgTblAdd("WM_QUIT", WM_QUIT);
    MsgTblAdd("WM_QUERYOPEN", WM_QUERYOPEN);
    MsgTblAdd("WM_ERASEBKGND", WM_ERASEBKGND);
    MsgTblAdd("WM_SYSCOLORCHANGE", WM_SYSCOLORCHANGE);
    MsgTblAdd("WM_ENDSESSION", WM_ENDSESSION);
    MsgTblAdd("WM_SHOWWINDOW", WM_SHOWWINDOW);
    MsgTblAdd("WM_WININICHANGE", WM_WININICHANGE);
    MsgTblAdd("WM_SETTINGCHANGE", WM_SETTINGCHANGE);
    MsgTblAdd("WM_DEVMODECHANGE", WM_DEVMODECHANGE);
    MsgTblAdd("WM_ACTIVATEAPP", WM_ACTIVATEAPP);
    MsgTblAdd("WM_FONTCHANGE", WM_FONTCHANGE);
    MsgTblAdd("WM_TIMECHANGE", WM_TIMECHANGE);
    MsgTblAdd("WM_CANCELMODE", WM_CANCELMODE);
    MsgTblAdd("WM_SETCURSOR", WM_SETCURSOR);
    MsgTblAdd("WM_MOUSEACTIVATE", WM_MOUSEACTIVATE);
    MsgTblAdd("WM_CHILDACTIVATE", WM_CHILDACTIVATE);
    MsgTblAdd("WM_QUEUESYNC", WM_QUEUESYNC);
    MsgTblAdd("WM_GETMINMAXINFO", WM_GETMINMAXINFO);
    MsgTblAdd("WM_PAINTICON", WM_PAINTICON);
    MsgTblAdd("WM_ICONERASEBKGND", WM_ICONERASEBKGND);
    MsgTblAdd("WM_NEXTDLGCTL", WM_NEXTDLGCTL);
    MsgTblAdd("WM_SPOOLERSTATUS", WM_SPOOLERSTATUS);
    MsgTblAdd("WM_DRAWITEM", WM_DRAWITEM);
    MsgTblAdd("WM_MEASUREITEM", WM_MEASUREITEM);
    MsgTblAdd("WM_DELETEITEM", WM_DELETEITEM);
    MsgTblAdd("WM_VKEYTOITEM", WM_VKEYTOITEM);
    MsgTblAdd("WM_CHARTOITEM", WM_CHARTOITEM);
    MsgTblAdd("WM_SETFONT", WM_SETFONT);
    MsgTblAdd("WM_GETFONT", WM_GETFONT);
    MsgTblAdd("WM_SETHOTKEY", WM_SETHOTKEY);
    MsgTblAdd("WM_GETHOTKEY", WM_GETHOTKEY);
    MsgTblAdd("WM_QUERYDRAGICON", WM_QUERYDRAGICON);
    MsgTblAdd("WM_COMPAREITEM", WM_COMPAREITEM);
    MsgTblAdd("WM_COMPACTING", WM_COMPACTING);
    MsgTblAdd("WM_COMMNOTIFY", WM_COMMNOTIFY);
    MsgTblAdd("WM_WINDOWPOSCHANGING", WM_WINDOWPOSCHANGING);
    MsgTblAdd("WM_WINDOWPOSCHANGED", WM_WINDOWPOSCHANGED);
    MsgTblAdd("WM_POWER", WM_POWER);
    MsgTblAdd("WM_COPYDATA", WM_COPYDATA);
    MsgTblAdd("WM_CANCELJOURNAL", WM_CANCELJOURNAL);
    MsgTblAdd("WM_NOTIFY", WM_NOTIFY);
    MsgTblAdd("WM_INPUTLANGCHANGEREQUEST", WM_INPUTLANGCHANGEREQUEST);
    MsgTblAdd("WM_INPUTLANGCHANGE", WM_INPUTLANGCHANGE);
    MsgTblAdd("WM_TCARD", WM_TCARD);
    MsgTblAdd("WM_HELP", WM_HELP);
    MsgTblAdd("WM_USERCHANGED", WM_USERCHANGED);
    MsgTblAdd("WM_NOTIFYFORMAT", WM_NOTIFYFORMAT);
    MsgTblAdd("WM_CONTEXTMENU", WM_CONTEXTMENU);
    MsgTblAdd("WM_STYLECHANGING", WM_STYLECHANGING);
    MsgTblAdd("WM_STYLECHANGED", WM_STYLECHANGED);
    MsgTblAdd("WM_DISPLAYCHANGE", WM_DISPLAYCHANGE);
    MsgTblAdd("WM_GETICON", WM_GETICON);
    MsgTblAdd("WM_SETICON", WM_SETICON);
    MsgTblAdd("WM_NCCREATE", WM_NCCREATE);
    MsgTblAdd("WM_NCDESTROY", WM_NCDESTROY);
    MsgTblAdd("WM_NCCALCSIZE", WM_NCCALCSIZE);
    MsgTblAdd("WM_NCHITTEST", WM_NCHITTEST);
    MsgTblAdd("WM_NCPAINT", WM_NCPAINT);
    MsgTblAdd("WM_NCACTIVATE", WM_NCACTIVATE);
    MsgTblAdd("WM_GETDLGCODE", WM_GETDLGCODE);
    MsgTblAdd("WM_SYNCPAINT", WM_SYNCPAINT);
    MsgTblAdd("WM_NCMOUSEMOVE", WM_NCMOUSEMOVE);
    MsgTblAdd("WM_NCLBUTTONDOWN", WM_NCLBUTTONDOWN);
    MsgTblAdd("WM_NCLBUTTONUP", WM_NCLBUTTONUP);
    MsgTblAdd("WM_NCLBUTTONDBLCLK", WM_NCLBUTTONDBLCLK);
    MsgTblAdd("WM_NCRBUTTONDOWN", WM_NCRBUTTONDOWN);
    MsgTblAdd("WM_NCRBUTTONUP", WM_NCRBUTTONUP);
    MsgTblAdd("WM_NCRBUTTONDBLCLK", WM_NCRBUTTONDBLCLK);
    MsgTblAdd("WM_NCMBUTTONDOWN", WM_NCMBUTTONDOWN);
    MsgTblAdd("WM_NCMBUTTONUP", WM_NCMBUTTONUP);
    MsgTblAdd("WM_NCMBUTTONDBLCLK", WM_NCMBUTTONDBLCLK);
    MsgTblAdd("WM_KEYFIRST", WM_KEYFIRST);
    MsgTblAdd("WM_KEYDOWN", WM_KEYDOWN);
    MsgTblAdd("WM_KEYUP", WM_KEYUP);
    MsgTblAdd("WM_CHAR", WM_CHAR);
    MsgTblAdd("WM_DEADCHAR", WM_DEADCHAR);
    MsgTblAdd("WM_SYSKEYDOWN", WM_SYSKEYDOWN);
    MsgTblAdd("WM_SYSKEYUP", WM_SYSKEYUP);
    MsgTblAdd("WM_SYSCHAR", WM_SYSCHAR);
    MsgTblAdd("WM_SYSDEADCHAR", WM_SYSDEADCHAR);
    MsgTblAdd("WM_KEYLAST", WM_KEYLAST);
    MsgTblAdd("WM_IME_STARTCOMPOSITION", WM_IME_STARTCOMPOSITION);
    MsgTblAdd("WM_IME_ENDCOMPOSITION", WM_IME_ENDCOMPOSITION);
    MsgTblAdd("WM_IME_COMPOSITION", WM_IME_COMPOSITION);
    MsgTblAdd("WM_IME_KEYLAST", WM_IME_KEYLAST);
    MsgTblAdd("WM_INITDIALOG", WM_INITDIALOG);
    MsgTblAdd("WM_COMMAND", WM_COMMAND);
    MsgTblAdd("WM_SYSCOMMAND", WM_SYSCOMMAND);
    MsgTblAdd("WM_TIMER", WM_TIMER);
    MsgTblAdd("WM_HSCROLL", WM_HSCROLL);
    MsgTblAdd("WM_VSCROLL", WM_VSCROLL);
    MsgTblAdd("WM_INITMENU", WM_INITMENU);
    MsgTblAdd("WM_INITMENUPOPUP", WM_INITMENUPOPUP);
    MsgTblAdd("WM_MENUSELECT", WM_MENUSELECT);
    MsgTblAdd("WM_MENUCHAR", WM_MENUCHAR);
    MsgTblAdd("WM_ENTERIDLE", WM_ENTERIDLE);
    MsgTblAdd("WM_CTLCOLORMSGBOX", WM_CTLCOLORMSGBOX);
    MsgTblAdd("WM_CTLCOLOREDIT", WM_CTLCOLOREDIT);
    MsgTblAdd("WM_CTLCOLORLISTBOX", WM_CTLCOLORLISTBOX);
    MsgTblAdd("WM_CTLCOLORBTN", WM_CTLCOLORBTN);
    MsgTblAdd("WM_CTLCOLORDLG", WM_CTLCOLORDLG);
    MsgTblAdd("WM_CTLCOLORSCROLLBAR", WM_CTLCOLORSCROLLBAR);
    MsgTblAdd("WM_CTLCOLORSTATIC", WM_CTLCOLORSTATIC);
    MsgTblAdd("WM_MOUSEFIRST", WM_MOUSEFIRST);
    MsgTblAdd("WM_MOUSEMOVE", WM_MOUSEMOVE);
    MsgTblAdd("WM_LBUTTONDOWN", WM_LBUTTONDOWN);
    MsgTblAdd("WM_LBUTTONUP", WM_LBUTTONUP);
    MsgTblAdd("WM_LBUTTONDBLCLK", WM_LBUTTONDBLCLK);
    MsgTblAdd("WM_RBUTTONDOWN", WM_RBUTTONDOWN);
    MsgTblAdd("WM_RBUTTONUP", WM_RBUTTONUP);
    MsgTblAdd("WM_RBUTTONDBLCLK", WM_RBUTTONDBLCLK);
    MsgTblAdd("WM_MBUTTONDOWN", WM_MBUTTONDOWN);
    MsgTblAdd("WM_MBUTTONUP", WM_MBUTTONUP);
    MsgTblAdd("WM_MBUTTONDBLCLK", WM_MBUTTONDBLCLK);
    MsgTblAdd("WM_MOUSELAST", WM_MOUSELAST);
    MsgTblAdd("WM_PARENTNOTIFY", WM_PARENTNOTIFY);
    MsgTblAdd("WM_ENTERMENULOOP", WM_ENTERMENULOOP);
    MsgTblAdd("WM_EXITMENULOOP", WM_EXITMENULOOP);
    MsgTblAdd("WM_NEXTMENU", WM_NEXTMENU);
    MsgTblAdd("WM_SIZING", WM_SIZING);
    MsgTblAdd("WM_CAPTURECHANGED", WM_CAPTURECHANGED);
    MsgTblAdd("WM_MOVING", WM_MOVING);
    MsgTblAdd("WM_POWERBROADCAST", WM_POWERBROADCAST);
    MsgTblAdd("WM_DEVICECHANGE", WM_DEVICECHANGE);
    MsgTblAdd("WM_MDICREATE", WM_MDICREATE);
    MsgTblAdd("WM_MDIDESTROY", WM_MDIDESTROY);
    MsgTblAdd("WM_MDIACTIVATE", WM_MDIACTIVATE);
    MsgTblAdd("WM_MDIRESTORE", WM_MDIRESTORE);
    MsgTblAdd("WM_MDINEXT", WM_MDINEXT);
    MsgTblAdd("WM_MDIMAXIMIZE", WM_MDIMAXIMIZE);
    MsgTblAdd("WM_MDITILE", WM_MDITILE);
    MsgTblAdd("WM_MDICASCADE", WM_MDICASCADE);
    MsgTblAdd("WM_MDIICONARRANGE", WM_MDIICONARRANGE);
    MsgTblAdd("WM_MDIGETACTIVE", WM_MDIGETACTIVE);
    MsgTblAdd("WM_MDISETMENU", WM_MDISETMENU);
    MsgTblAdd("WM_ENTERSIZEMOVE", WM_ENTERSIZEMOVE);
    MsgTblAdd("WM_EXITSIZEMOVE", WM_EXITSIZEMOVE);
    MsgTblAdd("WM_DROPFILES", WM_DROPFILES);
    MsgTblAdd("WM_MDIREFRESHMENU", WM_MDIREFRESHMENU);
    MsgTblAdd("WM_IME_SETCONTEXT", WM_IME_SETCONTEXT);
    MsgTblAdd("WM_IME_NOTIFY", WM_IME_NOTIFY);
    MsgTblAdd("WM_IME_CONTROL", WM_IME_CONTROL);
    MsgTblAdd("WM_IME_COMPOSITIONFULL", WM_IME_COMPOSITIONFULL);
    MsgTblAdd("WM_IME_SELECT", WM_IME_SELECT);
    MsgTblAdd("WM_IME_CHAR", WM_IME_CHAR);
    MsgTblAdd("WM_IME_KEYDOWN", WM_IME_KEYDOWN);
    MsgTblAdd("WM_IME_KEYUP", WM_IME_KEYUP);
    MsgTblAdd("WM_CUT", WM_CUT);
    MsgTblAdd("WM_COPY", WM_COPY);
    MsgTblAdd("WM_PASTE", WM_PASTE);
    MsgTblAdd("WM_CLEAR", WM_CLEAR);
    MsgTblAdd("WM_UNDO", WM_UNDO);
    MsgTblAdd("WM_RENDERFORMAT", WM_RENDERFORMAT);
    MsgTblAdd("WM_RENDERALLFORMATS", WM_RENDERALLFORMATS);
    MsgTblAdd("WM_DESTROYCLIPBOARD", WM_DESTROYCLIPBOARD);
    MsgTblAdd("WM_DRAWCLIPBOARD", WM_DRAWCLIPBOARD);
    MsgTblAdd("WM_PAINTCLIPBOARD", WM_PAINTCLIPBOARD);
    MsgTblAdd("WM_VSCROLLCLIPBOARD", WM_VSCROLLCLIPBOARD);
    MsgTblAdd("WM_SIZECLIPBOARD", WM_SIZECLIPBOARD);
    MsgTblAdd("WM_ASKCBFORMATNAME", WM_ASKCBFORMATNAME);
    MsgTblAdd("WM_CHANGECBCHAIN", WM_CHANGECBCHAIN);
    MsgTblAdd("WM_HSCROLLCLIPBOARD", WM_HSCROLLCLIPBOARD);
    MsgTblAdd("WM_QUERYNEWPALETTE", WM_QUERYNEWPALETTE);
    MsgTblAdd("WM_PALETTEISCHANGING", WM_PALETTEISCHANGING);
    MsgTblAdd("WM_PALETTECHANGED", WM_PALETTECHANGED);
    MsgTblAdd("WM_HOTKEY", WM_HOTKEY);
    MsgTblAdd("WM_PRINT", WM_PRINT);
    MsgTblAdd("WM_PRINTCLIENT", WM_PRINTCLIENT);
    MsgTblAdd("WM_HANDHELDFIRST", WM_HANDHELDFIRST);
    MsgTblAdd("WM_HANDHELDLAST", WM_HANDHELDLAST);
    MsgTblAdd("WM_AFXFIRST", WM_AFXFIRST);
    MsgTblAdd("WM_AFXLAST", WM_AFXLAST);
    MsgTblAdd("WM_PENWINFIRST", WM_PENWINFIRST);
    MsgTblAdd("WM_PENWINLAST", WM_PENWINLAST);
    MsgTblAdd("WM_APP", WM_APP);
    MsgTblAdd("WM_USER", WM_USER);
}


/* Used only for tobe's build. */
int SendMsg_SafeInit(Tcl_Interp *interp) {
    return TCL_ERROR;
}
int SendMsg_Init(Tcl_Interp *interp)
{
    Tcl_MutexLock(&initLock);

    if (MsgTblinit) {
	Fill_MsgTable();
        MsgTblinit=1;
    }

    Tcl_MutexUnlock(&initLock);

    Tcl_CreateObjCommand(interp, "winutils::sendmessage", SendMessageObjCmd, 0L, 0L);
    Tcl_CreateObjCommand(interp, "winutils::pidhwnd", PidHwndObjCmd, 0L, 0L);
    return TCL_OK;
}
