static char const rcsid[] = "@(#) $Id: main.c,v 1.7 2010/01/04 23:04:52 pcmacdon Exp $";
/*
** This file implements the main routine for a standalone Tcl/Tk shell.
*/
#if BUILDTK
#include <tk.h>
#else
#include <tcl.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

/*
** We will be linking against all of these extensions.
*/
#if BUILDTK
#ifdef __WIN32__
#include <windows.h>
#include <locale.h>
void
XPutImage(display, d, gc, image, src_x, src_y, dest_x, dest_y, width, height)
    Display* display;
    Drawable d;
    GC gc;
    XImage* image;
    int src_x;
    int src_y;
    int dest_x;
    int dest_y;
    unsigned int width;
    unsigned int height;
{
}
#endif

static int usetk=1;
#else
static int usetk=0;
#endif
extern int Zvfs_Mount(Tcl_Interp*, CONST char*, CONST char *);
static Tcl_DString pStr;

/*
** This is the event loop
*/
static char zWaitForever[] = 
  "bind . <Destroy> {+if {\"%W\"==\".\"} exit}\n"
  "while 1 {vwait forever}"
;

extern void (*Zvfs_PostInit)(Tcl_Interp*);

FILE *F=0;
static void zvfsvarsetup(Tcl_Interp *interp) {
  struct stat sb;
  char *tkl, *tcll;
  Tcl_DString dStr, kStr;

  Tcl_DStringInit(&dStr);
  Tcl_DStringInit(&kStr);
  Tcl_DStringAppend(&dStr, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&dStr, "/tcl", -1);
  Tcl_DStringAppend(&dStr, TCL_VERSION, -1);
  Tcl_DStringAppend(&kStr, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&kStr, "/tk", -1);
  Tcl_DStringAppend(&kStr, TCL_VERSION, -1);
  tcll = Tcl_DStringValue(&dStr);
  tkl = Tcl_DStringValue(&kStr);
  
  //if (stat(tcll,&sb) || stat(tkl,&sb)) {
      // ??
//    strcpy(tcll,"/zvfs/tcl8.4");
//    strcpy(tkl,"/zvfs/tk8.4");
  //}
  Tcl_SetVar(interp, "tcl_library", tcll, TCL_GLOBAL_ONLY);
  Tcl_SetVar2(interp, "env", "TCL_LIBRARY", tcll, TCL_GLOBAL_ONLY);
#if BUILDTK
  Tcl_SetVar(interp, "tk_library", tkl, TCL_GLOBAL_ONLY);
  Tcl_SetVar2(interp, "env", "TK_LIBRARY", tkl, TCL_GLOBAL_ONLY);
//  Tcl_SetVar(interp, "blt_library", "/zvfs/blt", TCL_GLOBAL_ONLY);
//  Tcl_SetVar2(interp, "env", "BLT_LIBRARY", "/zvfs/blt", TCL_GLOBAL_ONLY);
#endif
  Tcl_DStringFree(&dStr);
  Tcl_DStringFree(&kStr);
}

static int mountrc;
static int initcons=0;
static void zfspostinit(Tcl_Interp *interp) {
  CONST char *cp=Tcl_GetNameOfExecutable();
  if ((mountrc=Zvfs_Mount(interp, cp, Tcl_DStringValue(&pStr))) != TCL_OK) {
    if (F) fprintf(F," ZVFS mount error on %s: %s\n",cp,interp->result);
  } else {
    Tcl_SetVar(interp, "TOBEPATH", cp, TCL_GLOBAL_ONLY);
    zvfsvarsetup(interp);
  }
}

/* Exclude initialization of an extension. */
int ExcludeExtn(CONST char *excludes, CONST char *includes, CONST char *name) {
  CONST char *cp;
  int len;
  if ((!excludes) && (!includes))
    return 0;
  if (includes) {
    if (!strcmp(name,"Tk"))
      return 0;
    if (!(cp=strstr(name, includes)))
      return 1;
    len=strlen(name);
    if ((!cp[len]) || isspace(cp[len]))
      return 0;
    return 1;
  }
  if (!(cp=strstr(name, excludes)))
    return 0;
  len=strlen(name);
  if ((!cp[len]) || isspace(cp[len]))
    return 1;
  return 0;
}

#define _TCLEXTN(name) \
  extern int name##_Init(Tcl_Interp*); \
  if (!ExcludeExtn(excludes,includes,#name)) { \
    if (name##_Init(interp)) {\
      if (F) fprintf(F,"%s Failure %s\n",#name,  interp->result); \
      printf("%s Failed to initialize: %s\n",#name,  interp->result); \
      return 1; \
    } \
  }

#define TCLEXTN(name) {\
  _TCLEXTN(name) \
}

#define TCLEXTNS(name) {\
  extern int name##_SafeInit(Tcl_Interp*); \
  _TCLEXTN(name) \
  Tcl_StaticPackage(interp,#name, name##_Init, name##_SafeInit); \
}

#define TKEXTN(name) if (usetk) {\
  TCLEXTN(name) \
}
#define TKEXTNS(name) {\
  extern int name##_SafeInit(Tcl_Interp*); \
  extern int name##_Init(Tcl_Interp*); \
  if (usetk) { _TCLEXTN(name) } \
  Tcl_StaticPackage(usetk?interp:NULL,#name, name##_Init, name##_SafeInit); \
}

static CONST char *wizdebug;
static CONST char *tclonly;
static CONST char *excludes;
static CONST char *includes;
static CONST char *wizconsole;

static int WizConsoleCommand(
  ClientData clientData,	/* Client data for this command */
  Tcl_Interp *interp,		/* The interpreter used to report errors */
  int argc,			/* Number of arguments */
  CONST char *argv[]		/* Values of all arguments */
){
   int wizcons=0;
#if (defined(__WIN32__) || defined(_WIN32))
   wizcons=1;
#else
   wizcons=(getenv("WIZCONSOLE")!=NULL);
#endif
  // if ((!usetk) || (!wizcons)) return;
#if BUILDTK
  if (!initcons) {
     Tk_InitConsoleChannels(interp);
     initcons=1;
  }
  Tk_CreateConsoleWindow(interp);
#endif
  return TCL_OK;
}

static const char ev[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static int atend;

static int
getidx(char *buffer, int len, int *posn) {
    char c;
    char *idx;
    if (atend) return -1;
    do {
    if ((*posn)>=len) {
        atend = 1;
        return -1;
    }
    c = buffer[(*posn)++];
    if (c<0 || c=='=') {
        atend = 1;
        return -1;
    }
    idx = strchr(ev, c);
    } while (!idx);
    return idx - ev; 
} 


base64decode(ClientData clientData, Tcl_Interp *interp,
    int objc, Tcl_Obj *CONST objv[]) 
{
    Tcl_Obj *o;
    char *inbuffer;
    int ilen, olen, pos, tlen=1024, tpos=0;
    char outbuffer[3], *tbuf;
    int c[4];

    if (objc!=2) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("needs one argument "
        "(string to decode)", -1));
        return TCL_ERROR;
    }
    tbuf=(char*)malloc(tlen);
    inbuffer = Tcl_GetStringFromObj(objv[1], &ilen);
    pos = 0; 
    atend = 0;
    while (!atend) {
        if (inbuffer[pos]=='\n' ||inbuffer[pos]=='\r') { pos++; continue; }
        c[0] = getidx(inbuffer, ilen, &pos);
        c[1] = getidx(inbuffer, ilen, &pos);
        c[2] = getidx(inbuffer, ilen, &pos);
        c[3] = getidx(inbuffer, ilen, &pos);

        olen = 0;
        if (c[0]>=0 && c[1]>=0) {
            outbuffer[0] = ((c[0]<<2)&0xfc)|((c[1]>>4)&0x03);
            olen++;
            if (c[2]>=0) {
                outbuffer[1] = ((c[1]<<4)&0xf0)|((c[2]>>2)&0x0f);
                olen++;
                if (c[3]>=0) {
                    outbuffer[2] = ((c[2]<<6)&0xc0)|((c[3])&0x3f);
                    olen++;
                }
            }
        }

        /*fprintf(stderr,"OB(%d): %x,%x,%x\n", olen,outbuffer[0],outbuffer[1],outbuffer[2]);*/
        if (olen>0) {
            if ((tpos+olen+1)>=tlen) {
                tbuf=realloc(tbuf,tlen+1024);
                tlen+=1024;
            }
            memcpy(tbuf+tpos,outbuffer,olen);
            tpos+=olen;
        }
    }
    o=Tcl_NewByteArrayObj(tbuf,tpos);
    Tcl_IncrRefCount (o);
    Tcl_SetObjResult (interp,o);
    Tcl_DecrRefCount (o);
    Tcl_SetObjResult(interp, o);
    free(tbuf);
    return TCL_OK;
}

int
base64encode(ClientData clientData, Tcl_Interp *interp,
    int objc, Tcl_Obj *CONST objv[]) 
{
    Tcl_Obj *result;
    char *ib;
    int i=0, ilen, olen, pos=0;
    char c[74];

    if (objc!=2) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("needs one argument "
        "(string to encode)", -1));
        return TCL_ERROR;
    }
    ib= Tcl_GetByteArrayFromObj (objv[1], &ilen);
    result = Tcl_NewStringObj("", 0);
    while (pos<ilen) {
#define P(n,s) ((pos+n)>ilen?'=':ev[s])
        c[i++]=ev[(ib[pos]>>2)&0x3f];
        c[i++]=P(1,((ib[pos]<<4)&0x30)|((ib[pos+1]>>4)&0x0f));
        c[i++]=P(2,((ib[pos+1]<<2)&0x3c)|((ib[pos+2]>>6)&0x03));
        c[i++]=P(3,ib[pos+2]&0x3f);
        if (i>=72) {
            c[i++]='\n';
            c[i]=0;
            Tcl_AppendToObj(result, c, i);
            i=0;
        }
        pos+=3;
    }
    if (i) {
        /*    c[i++]='\n';*/
        c[i]=0;
        Tcl_AppendToObj(result, c, i);
        i=0;
    }
    Tcl_SetObjResult(interp, result);
    return TCL_OK;
}

/* BSD copyright 2008 - Peter MacDonald - http://pdqi.com
 * Xor-salt encryption.  Returns encrypted string of length len
 * where in-len == out-len and odata and data may be the same.
 * If odata is NULL, it gets alloc'ed.
 * The value of saltsz is >=0 && <=256. Typical values: 4 or 8.
 */
static char *
saltxorstr(
    int plen,
    char *password,
    int len,
    char *data,
    char *odata,
    int saltsz
) {
    unsigned char *ip, *pp, *ib, *c, rval, seed, salts[256], ppBuf[BUFSIZ+20];
    int i=0, j, p, n, random = 0;

    ip = password;
    ib = data;
    if (plen<1) {
        return NULL;
    }
    if (saltsz<0 || saltsz>256) {
        return NULL;
    }
    if (odata != NULL) {
        c = (unsigned char *)odata;
    } else {
        c = (unsigned char *)ckalloc(len*sizeof(unsigned char));
    }
    if (plen<BUFSIZ) {
        pp = ppBuf;
    } else {
        pp = (unsigned char *)ckalloc((plen+20)*sizeof(unsigned char));
    }
    strcpy(pp, ip);
    for (i=0; i<16; i++) {
        pp[plen+i] = ip[i%plen];
    }
    p = -1;
    if (saltsz) {
        for (i=0; i<saltsz; i++) {
            salts[i] = 0;
        }
        /* Rotate password bits 90 degrees and skew. */
        for (i=0; i<plen; i+=8) {
            for (j=0; j<8; j++) {
                unsigned char nv;
                nv = (pp[i+j]&0x1)|(pp[i+j+4]&0x10)| \
                (pp[i+j+1]&0x2)|(pp[i+j+5]&0x20)| \
                (pp[i+j+2]&0x4)|(pp[i+j+6]&0x40)| \
                (pp[i+j+3]&0x8)|(pp[i+j+7]&0x80);
                salts[j%saltsz] ^= nv;
            }
        }
        /* Use full password to generate the seed starting value. */
        seed = ip[0];
        for (i=1; i<plen; i++) {
            seed=seed^ip[i];
        }
        p = ((seed%plen)-1);
    }
    n = -1;
    for (i=0; i<len; i++) {
        n = ((n+1)%saltsz);
        p++;
        if (p>=plen) p=0;
        rval=ip[p];
        if (saltsz) {
            /* At irregular intervals shuffle the salts and seed. */
            if (((p+random)%plen) == (seed%plen)) {
                random = seed;
                seed ^= salts[p%saltsz];
                for (j=0; j<saltsz; j++) {
                    salts[j] = ((salts[j]<<1) | ((salts[j]&0x80) != 0));
                }
            }
            rval = ((ip[p]^salts[n])^seed);
        }
        c[i] = (ib[i]^rval);
    }
    if (pp != ppBuf) {
        ckfree(pp);
    }
    return (char *)c;
}

/*
 * Xor based symmetric encryption.
 * If called with -nosalt or -saltsize 0, fall back to plain old xor.
 */
static int
xorstrcmd(ClientData clientData, Tcl_Interp *interp,
    int objc, Tcl_Obj *CONST objv[]) 
{
    Tcl_Obj *result;
    char *ib;
    char *ip;
    int plen, olen, saltsz=8;
    unsigned char *c, cBuf[BUFSIZ+10];

    while (1) {
        if ( objc>=4 && strcmp("-nosalt", Tcl_GetString(objv[1])) == 0) {
            saltsz=0;
            objc--;
            objv++;
            continue;
        }
        if ( objc>=5 && strcmp("-saltsize", Tcl_GetString(objv[1])) == 0) {
            if (Tcl_GetIntFromObj(interp, objv[2], &saltsz) != TCL_OK) {
                return TCL_ERROR;
            }
            if (saltsz<0 || saltsz>256) {
                Tcl_SetObjResult(interp, Tcl_NewStringObj("salt <0 or >256 ", -1));
                return TCL_ERROR;
            }
            objc-=2;
            objv+=2;
            continue;
        }
        break;
    }
    if (objc != 3) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj(
        "usage: xorcrypt ?-nosalt? ?-saltsize N? password data", -1));
        return TCL_ERROR;
    }
    ip = Tcl_GetStringFromObj(objv[1], &plen);
    ib = Tcl_GetByteArrayFromObj(objv[2], &olen);
    if (plen<1) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("null password", -1));
        return TCL_ERROR;
    }
    c = saltxorstr(plen, ip, olen, ib, (olen<BUFSIZ?cBuf:NULL), saltsz);
    if (c == NULL) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("crypt failure", -1));
        return TCL_ERROR;
    }
    result=Tcl_NewByteArrayObj(c, olen);
    if (c != cBuf) {
        ckfree(c);
    }
    Tcl_SetObjResult(interp, result);
    return TCL_OK;
}


/* Must be the same as in tclInt.h */
enum tclWarnEnum {
    WARN_LEVEL,	   /* The debug level. */
    WARN_MASK,	   /* Mask warning classes */
    WARN_NOWARN,   /* #NOWARN: directive from comment. */
    WARN_FILTERED, /* Count of filtered warnings. */
    WARN_VERSION,  /* The tcl version as an int value: 80501 for 8.5.1. */
    WARN_RUNVER,   /* The runtime version (ie. without overridden value). */
    WARN_WELDVER,  /* Weld version number: eg 1.1.3 = 10103. */
    WARN_SUBPROC,  /* Sub-process output, ie for emacs. */
    WARN_STRICT,   /* Force trict type checking. */
    WARN_PROFILE,  /* Profile calls to proc. */
    WARN_COVERAGE, /* Do code coverage. */
    WARN_DEBUG,    /* Debug program. */
    WARN_CALLS,    /* Display calls. */
    WARN_MSGCAT,   /* Collect all calls to msgcat/mc. */
    WARN_UNUSED,   /* Warn when no calls to a proc are compiled. */
    WARN_CTAGS,    /* Generate ctags for functions. */
    WARN_NOFILT,   /* 1=Disable filtering, 2=filter only implicits. */
    WARN_NOCALLBACK, /* Disable checking of the types 'cmd' and 'code' */
    WARN_LEVELNAME,  /* String for level. */
    WARN_STARTTIME,  /* Time interp was created. */
    WARN_PROCCALLS,  /* Trace proc calls (1/2 call/return, 4/8 includes _*). */
    WARN_ALLCALLS,   /* Trace all calls. */
    WARN_TRAP,       /* Trap errorInfo updates (externally). */
    WARN_NOXFT       /* Do not use Unix XFT font server, if possible. */
};
extern int tclWarnVar[];
extern Tcl_Interp *tclMainInterp;

int
LocInit(interp)
    Tcl_Interp *interp;         /* Interpreter for application. */
{
    int rc; /*, tty; */
    CONST char *cp;
  Tcl_DString cmd, dStr;
  TCLEXTN(Tcl)
  /*tty = isatty(0);
   Tcl_SetVar(interp, "tcl_interactive", tty?"1":"0", TCL_GLOBAL_ONLY); */
#if BUILDTK
  if (tclWarnVar[WARN_NOXFT]) {
#ifndef WIN32
      TkpFontUseX11();
#endif
  }
  TKEXTNS(Tk)
#endif
  if( Tcl_InitStubs(interp,"8.0",0)==0 ){
    return TCL_ERROR;
  }

  if (!getenv("TCL_NOEXT")) {
      INITEXTENSIONS
  }
  Tcl_CreateObjCommand( interp, "::Wiz::xorcrypt", xorstrcmd,
                         (ClientData)0, NULL);
  Tcl_CreateObjCommand( interp, "::Wiz::b64encode", base64encode,
                         (ClientData)0, NULL);
  Tcl_CreateObjCommand( interp, "::Wiz::b64decode", base64decode,
                         (ClientData)0, NULL);
  Tcl_CreateObjCommand( interp, "::wiz::xorcrypt", xorstrcmd,
                         (ClientData)0, NULL);
  Tcl_CreateObjCommand( interp, "::wiz::b64encode", base64encode,
                         (ClientData)0, NULL);
  Tcl_CreateObjCommand( interp, "::wiz::b64decode", base64decode,
                         (ClientData)0, NULL);
  /* After all extensions are registered, start up the
  ** program by running /zvfs/main.tcl.
  */
#if 0
  Tcl_DStringInit(&cmd);
  Tcl_DStringAppend(&cmd, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&cmd, "/main.tcl", -1);
  rc=Tcl_SetStartupScript(Tcl_NewStringObj(Tcl_DStringValue(&cmd), -1), NULL);
  Tcl_DStringSetLength(&cmd, 0);
#endif

  //Tcl_CreateExitHandler(ExitHandler, (ClientData)interp);
  Tcl_DStringInit(&cmd);
//  Tcl_DStringAppend(&cmd, "source ", -1);
  Tcl_DStringAppend(&cmd, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&cmd, "/main.tcl", -1);
  rc=Tcl_EvalFile(interp, Tcl_DStringValue(&cmd));
  cp = Tcl_GetStringResult(interp);
  /* TODO: check file exists. */
  if (rc == 0 && cp && *cp) {
     rc=Tcl_SetStartupScript(Tcl_NewStringObj(cp,-1), NULL);
  }
  return rc;
}

void ExitHandler(ClientData clientData) {
    Tcl_Interp *interp = (Tcl_Interp*)clientData;
    Tcl_DeleteNamespace(Tcl_GetGlobalNamespace(interp));
}

#if (defined(__WIN32__) || defined(_WIN32))
#if defined(__GNUC__)
static void
setargv(argcPtr, argvPtr)
    int *argcPtr;		/* Filled with number of argument strings. */
    char ***argvPtr;		/* Filled with argument strings (malloc'd). */
{
    char *cmdLine, *p, *arg, *argSpace;
    char **argv;
    int argc, size, inquote, copy, slashes;

    cmdLine = GetCommandLine();	/* INTL: BUG */

    /*
     * Precompute an overly pessimistic guess at the number of arguments in
     * the command line by counting non-space spans.
     */

    size = 2;
    for (p = cmdLine; *p != '\0'; p++) {
	if ((*p == ' ') || (*p == '\t')) {	/* INTL: ISO space. */
	    size++;
	    while ((*p == ' ') || (*p == '\t')) { /* INTL: ISO space. */
		p++;
	    }
	    if (*p == '\0') {
		break;
	    }
	}
    }
    argSpace = (char *) Tcl_Alloc(
	    (unsigned) (size * sizeof(char *) + strlen(cmdLine) + 1));
    argv = (char **) argSpace;
    argSpace += size * sizeof(char *);
    size--;

    p = cmdLine;
    for (argc = 0; argc < size; argc++) {
	argv[argc] = arg = argSpace;
	while ((*p == ' ') || (*p == '\t')) {	/* INTL: ISO space. */
	    p++;
	}
	if (*p == '\0') {
	    break;
	}

	inquote = 0;
	slashes = 0;
	while (1) {
	    copy = 1;
	    while (*p == '\\') {
		slashes++;
		p++;
	    }
	    if (*p == '"') {
		if ((slashes & 1) == 0) {
		    copy = 0;
		    if ((inquote) && (p[1] == '"')) {
			p++;
			copy = 1;
		    } else {
			inquote = !inquote;
		    }
		}
		slashes >>= 1;
	    }

	    while (slashes) {
		*arg = '\\';
		arg++;
		slashes--;
	    }

	    if ((*p == '\0') || (!inquote &&
		    ((*p == ' ') || (*p == '\t')))) {	/* INTL: ISO space. */
		break;
	    }
	    if (copy != 0) {
		*arg = *p;
		arg++;
	    }
	    p++;
	}
	*arg = '\0';
	argSpace = arg + 1;
    }
    argv[argc] = NULL;

    *argcPtr = argc;
    *argvPtr = argv;
}
#endif /* __GNUC__ */
#endif

int main(int argc, char **argv){
  Tcl_Interp *interp;
  Tcl_DString cmd, dStr;
  CONST char *args, *emsg, *wePtr, *cp;
  char buf[100];
  int rc,i, iscover;
  /* TODO: Add md5 security check against eg. /etc/wizemd5.cnf to prevent
   * running tampered versions??? */
#if (defined(__WIN32__) || defined(_WIN32))
  char *p;

#if defined(__GNUC__)
  setargv( &argc, &argv );
#endif
  setlocale(LC_ALL, "C");

  /*
   *      * Forward slashes substituted for backslashes.
   *           */

  for (p = argv[0]; *p != '\0'; p++) {
      if (*p == '\\') {
	  *p = '/';
      }
  }

#else
  char *display=getenv("DISPLAY");
  if ((!display) || (!*display)) usetk=0;
#endif
  if ((cp=getenv("WIZNOTK")) && !strcmp(cp,"1")) { usetk = 0; }
  Tcl_DStringInit(&pStr);
  wizdebug=getenv("WIZDEBUG");
  tclonly=getenv("WIZCMD");
  excludes=getenv("WIZEXCLUDE");
  includes=getenv("WIZINCLUDE");
  wizconsole=getenv("WIZCONSOLE");
  if (tclonly && (!strncasecmp(tclonly,"tclsh",5))) usetk=0;

  /* Create a Tcl interpreter
  */
  Tcl_FindExecutable(argv[0]);
  if (getenv("WIZMOUNT")) {
      Tcl_DStringAppend(&pStr, Tcl_GetNameOfExecutable(), -1);
  } else if ((cp=getenv("WIZMNT"))) {
      Tcl_DStringAppend(&pStr, cp, -1);
  } else {
      Tcl_DStringAppend(&pStr, "/zvfs", -1);
  }
  interp = Tcl_CreateInterp();
#ifdef TCL_MEM_DEBUG
  Tcl_InitMemory(interp);
#endif
  //Tcl_SetVar(interp, "auto_path", Tcl_DStringValue(&pStr), TCL_APPEND_VALUE|TCL_LIST_ELEMENT);
  if( Tcl_PkgRequire(interp, "Tcl", TCL_PATCH_LEVEL, 1)==0 ){
    return 1;
  }
  if ((wePtr=getenv("WARN_NOFILT")) != NULL && *wePtr) {
     tclWarnVar[WARN_NOFILT] = atoi(wePtr);
  }
  if ((wePtr=getenv("TCL_WARN")) != NULL && *wePtr) {
      if (!Tcl_SetVar2(interp, "tcl_warn", "level", wePtr, TCL_GLOBAL_ONLY|TCL_LEAVE_ERR_MSG)) {
          fprintf(stderr, "ignoring bad tcl_warn: %s\n%s\n", wePtr,
                  Tcl_GetStringResult(interp));
      }
  }

  if ((argc >= 2) && (0 == strncmp("-W", argv[1], 2))) {
      if (!Tcl_SetVar2(interp, "tcl_warn","level", argv[1]+2,
                  TCL_GLOBAL_ONLY|TCL_LEAVE_ERR_MSG)) {
          fprintf(stderr, "ignoring bad tcl_warn: %s\n%s\n", argv[1],
                  Tcl_GetStringResult(interp));
      }
      argc -= 1;
      argv += 1;
  }

  Tcl_CreateCommand(interp, "Wiz::console", WizConsoleCommand, 0, 0);
  args = Tcl_Merge(argc-1, argv+1);
  Tcl_SetVar(interp, "argv", args, TCL_GLOBAL_ONLY);
  ckfree((char*)args);
  sprintf(buf, "%d", argc-1);
  Tcl_SetVar(interp, "argc", buf, TCL_GLOBAL_ONLY);
  Tcl_SetVar(interp, "argv0", argv[0], TCL_GLOBAL_ONLY);
  Tcl_DStringInit(&cmd);
  for (i=1; i<argc; i++) {
    if (!strcmp(argv[i],"-wiztclsh")) {
       usetk=0;
    } else if (!strcmp(argv[i],"-wizdebug")) {
       wizdebug="1";
    } else if (!strcmp(argv[i],"-wizconsole")) {
       wizconsole="1";
       Tcl_SetVar(interp, "env(WIZCONSOLE)","1",TCL_GLOBAL_ONLY);
    } else if ((i+1)<argc && (!strcmp(argv[i],"-wizexclude"))) {
      excludes = argv[++i];
    } else if ((i+1)<argc && (!strcmp(argv[i],"-wizinclude"))) {
      includes = argv[++i];
    } else {
      Tcl_DStringAppendElement(&cmd,argv[i]);
    }
  }
  if (wizdebug && *wizdebug != '0') {
    F=fopen("/tmp/wizdebug.log","w+");
    setbuf(F,0);
  }
  Tcl_SetVar(interp, "argv", Tcl_DStringValue(&cmd), TCL_GLOBAL_ONLY);
  Tcl_DStringFree(&cmd);

  Tcl_SetVar(interp, "tcl_interactive", "0", TCL_GLOBAL_ONLY);
  //Tcl_SetVar(interp, "WIZTCL", "1", TCL_GLOBAL_ONLY);

  if (F) fprintf(F,"STARTING ZVFS\n");
  Zvfs_PostInit=&zfspostinit;
  TCLEXTNS(Zvfs)
  if (F) fprintf(F,"ZVFS INITIALIZED %d\n", mountrc);
  if (mountrc == TCL_OK || getenv("NOMNT")) {
    zvfsvarsetup(interp);
  } else {
     /* If we fail to mount, we might as well fall back Tcl/Tk_Main. */
     Tcl_Main(argc, argv, LocInit);
     exit(0);
  }
  tclMainInterp = interp;
  Tcl_Main(argc, argv, LocInit);
  return 0;


#if 0
  TCLEXTN(Tcl)
  Tcl_DStringInit(&dStr);
  Tcl_DStringAppend(&dStr, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&dStr, "/tcl", -1);
  Tcl_DStringAppend(&dStr, TCL_VERSION, -1);
  TclSetLibraryPath(Tcl_NewStringObj(Tcl_DStringValue(&dStr),-1));
  Tcl_DStringFree(&dStr);
#if (defined(__WIN32__) || defined(_WIN32))
/*  inChannel = Tcl_GetStdChannel(TCL_STDIN);
  outChannel = Tcl_GetStdChannel(TCL_STDOUT);
  errChannel = Tcl_GetStdChannel(TCL_STDERR); */
#endif
#if BUILDTK
  TKEXTNS(Tk)
#endif


  if (!getenv("TCL_NOEXT")) {
      INITEXTENSIONS
  }
  /* After all extensions are registered, start up the
  ** program by running /zvfs/main.tcl.
  */
  Tcl_DStringInit(&cmd);
  Tcl_DStringAppend(&cmd, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&cmd, "/main.tcl", -1);
  rc=Tcl_SetStartupScript(Tcl_NewStringObj(Tcl_DStringValue(&cmd), -1), NULL);
  Tcl_DStringSetLength(&cmd, 0);
  //Tcl_CreateExitHandler(ExitHandler, (ClientData)interp);
  Tcl_DStringAppend(&cmd, "source ", -1);
  Tcl_DStringAppend(&cmd, Tcl_DStringValue(&pStr), -1);
  Tcl_DStringAppend(&cmd, "/main.tcl", -1);
  rc=Tcl_Eval(interp, Tcl_DStringValue(&cmd));

  Tcl_DStringFree(&cmd);
  iscover= (tclWarnVar[WARN_COVERAGE] ||
     tclWarnVar[WARN_PROFILE] ||
     tclWarnVar[WARN_UNUSED] ||
     tclWarnVar[WARN_CTAGS]);
  /* Ignore errors for coverage so Tcl_ExitObjCmd can unwind stack. */
  if (iscover) {
      TclCoverageDump(interp, NULL);
  } else if (rc && rc != 11) {
    emsg = Tcl_GetVar(interp, "errorInfo", TCL_GLOBAL_ONLY);
    fprintf(stderr,"RC=%d: %s\n%s",rc,interp->result,emsg?emsg:"");
    if (F) fprintf(F,"RC=%d: %s\n%s",rc,interp->result,emsg?emsg:"");
  }
  if (F) {
    fprintf(F,"DONE INIT\n");
    close(F); F=0;
  }
  if (rc != 11) {
   if (Tcl_GetVar(interp, "::tk_version", TCL_GLOBAL_ONLY))
     Tcl_Eval(interp, zWaitForever);
  }
  Tcl_DeleteInterp(interp);
  exit(rc);
#endif
}
