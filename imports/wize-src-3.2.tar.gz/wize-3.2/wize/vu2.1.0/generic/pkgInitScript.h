/* 
 * pkgInitScript.h --
 *
 *	This file contains Unix & Windows common init script
 *
 */

#include "version.h"
/*
 * In order to find tk.tcl during initialization, the following script
 * is invoked by Vu_Init().  It looks in several different directories:
 *
 *	$tk_library		- can specify a primary location, if set
 *				  no other locations will be checked
 *
 *	$env(TK_LIBRARY)	- highest priority so user can always override
 *				  the search path unless the application has
 *				  specified an exact directory above
 *
 *	$tcl_library/../tk$tk_version
 *				- look relative to init.tcl in an installed
 *				  lib directory (e.g. /usr/local)
 *
 *	<executable directory>/../lib/tk$tk_version
 *				- look for a lib/tk<ver> in a sibling of
 *				  the bin directory (e.g. /usr/local)
 *
 *	<executable directory>/../library
 *				- look in Tk build directory
 *
 *	<executable directory>/../../tk$tk_patchLevel/library
 *				- look for Tk build directory relative
 *				  to a parallel build directory
 *
 * The first directory on this path that contains a valid tk.tcl script
 * will be set ast the value of tk_library.
 *
 * Note that this entire search mechanism can be bypassed by defining an
 * alternate tkInit procedure before calling Tk_Init().
 */

static char initScript[] = "if {[info proc ::vu::Init]==\"\"} {\n\
  namespace eval ::vu {}\n\
  proc ::vu::Init {} {\n"
#ifdef MAC_TCL
"    source -rsrc vu.tcl\n"
#else
"    global vu_library\n\
    tcl_findLibrary vu " VU_VERSION " " VU_PATCH_LEVEL " vu.tcl VU_LIBRARY vu_library\n"
#endif
"  }\n\
}\n\
::vu::Init";

